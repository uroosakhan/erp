<?php

global $reports, $dim;

$reports->addReportClass(_('Payroll'), RC_PAYROLL);	
$reports->addReport(RC_PAYROLL, 2023, _('Employee Salary Advice'),
	array(	_('Month') => 'MONTH',
			_('Employee') => 'EMPLOYEE',
			_('Currency Filter') => 'CURRENCY',
			_('Suppress Zeros') => 'YES_NO',
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));		
$reports->addReport(RC_PAYROLL, 2012, _('Bank Letters'),
	array(	_('Month') => 'MONTH',			
			_('Banks') => 'BANK_ACCOUNTS',
			_('Letter Date') => 'DATE',
			_('Cheque') => 'TEXT',
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
/*
$reports->addReport(RC_PAYROLL, 2013, _('Salary Sheet'),
	array(	_('Month') => 'MONTH',			
			_('Department') => 'DEPT',
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
*/
$reports->addReport(RC_PAYROLL, 2014, _('Salary Sheet of Payroll'),
	array(	_('Month') => 'MONTH',			
			_('Department') => 'DEPT',
			_('Employee') => 'EMPLOYEE',
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
$reports->addReport(RC_PAYROLL, 2024, _('Employee Tax Report'),
	array(	_('Month') => 'MONTH',			
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
$reports->addReport(RC_PAYROLL, 2015, _('Sheet of Advance'),
	array(	_('Start Date') => 'DATEBEGINTAX',
			_('End Date') => 'DATEENDTAX',	
	       _('Approval') => 'UPROVE',			
			_('Department') => 'DEPT',
			_('Employee') => 'EMPLOYEE',
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
			
$reports->addReport(RC_PAYROLL, 2016, _('Sheet of Attendance'),
      array(_('Start Date') => 'DATEBEGINTAX',
			_('End Date') => 'DATEENDTAX',			
			_('Department') => 'DEPT',
			_('Employee') => 'EMPLOYEE',
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));	
$reports->addReport(RC_PAYROLL, 2017, _('Sheet of Overtime'),
  		array(_('Start Date') => 'DATEBEGINTAX',
			_('End Date') => 'DATEENDTAX',			
			_('Department') => 'DEPT',
			_('Employee') => 'EMPLOYEE',
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
$reports->addReport(RC_PAYROLL, 2018, _('Sheet of Leave'),
  		array(_('Start Date') => 'DATEBEGINTAX',
			_('End Date') => 'DATEENDTAX',
			 _('Approval') => 'UPROVE',			
			//_('Department') => 'DEPT',
			_('Employee') => 'EMPLOYEE',
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
$reports->addReport(RC_PAYROLL, 2019, _('Employee Master Sheet'),
 			array( _('Employee') => 'EMPLOYEE',
			_('Comments') => 'TEXTBOX',
			_('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));		
$reports->addReport(RC_PAYROLL, 2020, _('List of Departments'),
 			array( _('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
$reports->addReport(RC_PAYROLL, 2021, _('List of Designations'),
 			array( _('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
$reports->addReport(RC_PAYROLL, 2022, _('List of Grades'),
 			array( _('Orientation') => 'ORIENTATION',
			_('Destination') => 'DESTINATION'));
			
?>
